#!/usr/bin/env python3
"""mapper.py"""
import re
import sys

import urllib.request

regex = "https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+"


def main():

    for line in sys.stdin:
        url = line.strip()

        response = urllib.request.urlopen(url)
        html = response.read().decode("ISO-8859-1")

        urls = re.findall(regex, html)

        for inside_url in urls:
            print('<%s,\t%s>' % (url, inside_url))


if __name__ == '__main__':
    main()
