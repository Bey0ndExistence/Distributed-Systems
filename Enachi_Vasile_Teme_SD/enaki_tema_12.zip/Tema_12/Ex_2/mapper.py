#!/usr/bin/env python3
"""mapper.py"""
import re
import sys

import sqlite3
from sqlite3 import Error

regex = "(https?://(?:[-\w.])+)/?"


def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        sys.exit()

    return conn


def select_url_and_frequency(conn):
    cur = conn.cursor()
    cur.execute("SELECT url, frecency FROM moz_places")
    rows = list(cur.fetchall())
    cur.close()
    return rows


def main():
    for line in sys.stdin:
        database = line.strip()
        conn = create_connection(database)
        #conn = create_connection("places.sqlite")

        with conn:
            urls = select_url_and_frequency(conn)
            for link, frequency in urls:
                extract_url = re.search(regex, link)
                if extract_url and frequency and frequency > 0:
                    print('%s\t%s' % (extract_url.group(1), frequency))
        conn.close()


if __name__ == '__main__':
    main()
