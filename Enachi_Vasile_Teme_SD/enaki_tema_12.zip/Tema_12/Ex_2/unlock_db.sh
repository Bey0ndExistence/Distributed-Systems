#kill lock for places.sqlite
fuser -k /home/enaki/.mozilla/firefox/75mnjjna.default-release/places.sqlite