#!/usr/bin/env python3
"""reducer.py"""

import sys

current_letter = None
words = set()  #declare a set


def main():
    global current_letter
    for line in sys.stdin:
        #print(line)
        letter, word = line.split()  # line.split('\t', 1)
        # this IF-switch only works because Hadoop sorts map output
        # by key (here: word) before it is passed to the reducer
        if current_letter != letter:
            if len(words) > 0:
                print('<%s,\t%s>' % (current_letter, list(words)))
            current_letter = letter
            words.clear()

        words.add(word)

    if len(words) > 0:
        print('<%s,\t%s>' % (letter, list(words)))


if __name__ == '__main__':
    main()
