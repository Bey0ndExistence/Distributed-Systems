
source ~/.bashrc
stop-all.sh
rm -rf /tmp/hadoop-*
hdfs namenode -format -y
start-all.sh
