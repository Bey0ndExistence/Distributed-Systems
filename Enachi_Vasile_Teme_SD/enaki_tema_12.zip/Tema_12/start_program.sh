
#hdfs dfsadmin -safemode leave
hdfs dfs -rm -r /user/hduser/output
hdfs dfs -rm -r /user/hduser/input

hdfs dfs -mkdir -p /user/hduser/input

hdfs dfs -put /home/hduser/$1/input/* /user/hduser/input
hadoop jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming*.jar -input /user/hduser/input -output /user/hduser/output -mapper /home/hduser/$1/mapper.py -reducer /home/hduser/$1/reducer.py -file /home/hduser/$1/mapper.py -file /home/hduser/$1/reducer.py
