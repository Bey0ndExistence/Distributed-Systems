sudo cp -r $1/ /home/hduser
sudo chown -R hduser:hadoop /home/hduser/$1
