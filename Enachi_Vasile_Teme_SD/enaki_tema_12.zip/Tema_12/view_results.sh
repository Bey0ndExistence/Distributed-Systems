rm /home/hduser/part-00000
hdfs dfs -ls /user/hduser/output
hdfs dfs -get /user/hduser/output/part-00000 /home/hduser/
xdg-open /home/hduser/part-00000
