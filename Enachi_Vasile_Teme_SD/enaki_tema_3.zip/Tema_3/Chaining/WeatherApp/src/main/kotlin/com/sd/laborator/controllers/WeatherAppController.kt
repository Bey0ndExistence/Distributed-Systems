package com.sd.laborator.controllers
import com.sd.laborator.pojo.WeatherForecastData
import com.sd.laborator.services.TimeService
import com.sd.laborator.services.WeatherForecastService
import com.sd.laborator.services.WeatherForecastService_ID
import com.sd.laborator.services.WeatherForecastService_Location
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.ResponseBody

@Controller
class WeatherAppController {
    private var weatherForecastService: WeatherForecastService = WeatherForecastService_ID(TimeService())
    init {
        this.weatherForecastService.setNext(WeatherForecastService_Location(TimeService()))
    }

    @RequestMapping("/getforecast/{location}", method = [RequestMethod.GET])
    @ResponseBody
    fun getForecast(@PathVariable location: String): String {
        val rawForecastData: WeatherForecastData? = weatherForecastService.getForecastData(location)
        return rawForecastData?.toString() ?: "Nu s-a putut gasi nici un oras"
    }
}