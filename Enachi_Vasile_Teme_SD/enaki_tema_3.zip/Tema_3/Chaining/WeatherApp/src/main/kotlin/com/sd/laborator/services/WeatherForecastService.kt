package com.sd.laborator.services
import com.sd.laborator.interfaces.TimeInterface
import com.sd.laborator.interfaces.WeatherForecastInterface
import org.springframework.stereotype.Service
@Service
abstract class WeatherForecastService (protected val timeService: TimeInterface) : WeatherForecastInterface
{
    protected var wfsNext : WeatherForecastService? = null

    fun setNext(next : WeatherForecastService) {
        var latest = this
        while (latest.wfsNext != null){
            latest = latest.wfsNext!!
        }
        latest.wfsNext = next
    }
}