package com.sd.laborator.services

import com.sd.laborator.interfaces.TimeInterface
import com.sd.laborator.pojo.WeatherForecastData
import org.json.JSONObject
import java.net.URL
import kotlin.math.roundToInt

class WeatherForecastService_ID(timeService: TimeInterface) : WeatherForecastService(timeService) {
    override fun getForecastData(location: Any): WeatherForecastData? {
        var locationId : Int
        try{
            if (location !is String){
                return if (this.wfsNext != null) this.wfsNext!!.getForecastData(location) else null
            }
            locationId = location.toInt()
        } catch (nfe: NumberFormatException){
            return if (this.wfsNext != null) this.wfsNext!!.getForecastData(location) else null
        }
        var forecastDataURL : URL
        var rawResponse: String
        try {
            forecastDataURL = URL("https://www.metaweather.com/api/location/$locationId/")
            // preluare conţinut răspuns HTTP la o cerere GET către URL-ul de mai sus
            rawResponse = forecastDataURL.readText()
        } catch(e :java.io.FileNotFoundException){
            return null
        }

        val responseRootObject = JSONObject(rawResponse)
        val weatherDataObject = responseRootObject.getJSONArray("consolidated_weather").getJSONObject(0)
        return WeatherForecastData(
            location = responseRootObject.getString("title"),
            date = timeService.getCurrentTime(),
            weatherState = weatherDataObject.getString("weather_state_name"),
            weatherStateIconURL = "https://www.metaweather.com/static/img/weather/png/${weatherDataObject.getString("weather_state_abbr")}.png",
            windDirection = weatherDataObject.getString("wind_direction_compass"),
            windSpeed = weatherDataObject.getFloat("wind_speed").roundToInt(),
            minTemp = weatherDataObject.getFloat("min_temp").roundToInt(),
            maxTemp = weatherDataObject.getFloat("max_temp").roundToInt(),
            currentTemp = weatherDataObject.getFloat("the_temp").roundToInt(),
            humidity = weatherDataObject.getFloat("humidity").roundToInt()
        )
    }
}