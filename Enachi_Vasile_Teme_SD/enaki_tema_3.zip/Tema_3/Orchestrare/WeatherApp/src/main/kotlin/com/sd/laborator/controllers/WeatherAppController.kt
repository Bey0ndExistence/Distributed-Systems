package com.sd.laborator.controllers
import com.sd.laborator.pojo.WeatherForecastData
import com.sd.laborator.services.TimeService
import com.sd.laborator.services.WeatherForecastService
import com.sd.laborator.services.WeatherForecastService_ID
import com.sd.laborator.services.WeatherForecastService_Location
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.ResponseBody
import java.lang.NumberFormatException

@Controller
class WeatherAppController {
    private var weatherForecastService_Id : WeatherForecastService = WeatherForecastService_ID(TimeService())
    private var weatherForecastService_Location: WeatherForecastService =  WeatherForecastService_Location(TimeService())
    @RequestMapping("/getforecast/{location}", method = [RequestMethod.GET])
    @ResponseBody
    fun getForecast(@PathVariable location: String): String {
        return try{
            location.toInt()
            val rawForecastData: WeatherForecastData? = weatherForecastService_Id.getForecastData(location)
            rawForecastData?.toString() ?: "Nu s-a putut gasi nici un oras dupa acest id"
        } catch (nfe : NumberFormatException){
            val rawForecastData: WeatherForecastData? = weatherForecastService_Location.getForecastData(location)
            rawForecastData?.toString() ?: "Nu s-a putut gasi nici un oras"
        }
    }
}