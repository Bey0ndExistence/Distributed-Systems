package com.sd.laborator.interfaces

interface TimeInterface {
    fun getCurrentTime():String
}