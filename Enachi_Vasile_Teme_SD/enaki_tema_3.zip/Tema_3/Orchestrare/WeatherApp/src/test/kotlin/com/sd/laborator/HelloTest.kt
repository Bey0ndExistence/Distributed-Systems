package com.sd.laborator

import org.junit.Test
import kotlin.test.assertEquals

class HelloTest {

}
